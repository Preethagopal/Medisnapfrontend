package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProfileActivity : AppCompatActivity() {

    private lateinit var backBtn: ImageView
    private lateinit var moreBtn: ImageView
    private lateinit var firstName: EditText
    private lateinit var lastName: EditText
    private lateinit var phoneNumber: EditText
    private lateinit var genderSpinner: Spinner
    private lateinit var dob: EditText

    private lateinit var navHome: ImageView
    private lateinit var navSettings: ImageView
    private lateinit var navDocs: ImageView
    private lateinit var navProfile: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)

        // Handle insets for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        backBtn = findViewById(R.id.backBtn)
        moreBtn = findViewById(R.id.moreBtn)

        firstName = findViewById(R.id.firstName)
        lastName = findViewById(R.id.lastName)
        phoneNumber = findViewById(R.id.phoneNumber)
        genderSpinner = findViewById(R.id.genderSpinner)
        dob = findViewById(R.id.dob)

        navHome = findViewById(R.id.navHome)
        navSettings = findViewById(R.id.navSettings)
        navDocs = findViewById(R.id.navDocs)
        navProfile = findViewById(R.id.navProfile)

        // Back button → return to previous screen
        backBtn.setOnClickListener {
            finish()
        }

        // More/Dropdown button
        moreBtn.setOnClickListener {
            Toast.makeText(this, "More options clicked", Toast.LENGTH_SHORT).show()
        }

        // Bottom navigation
        navHome.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
            finish()
        }

        navSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        navDocs.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }

        navProfile.setOnClickListener {
            Toast.makeText(this, "Already on Profile page", Toast.LENGTH_SHORT).show()
        }
    }
}
