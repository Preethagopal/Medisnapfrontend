package com.simats.medisnap

import android.os.Bundle
import android.widget.ImageView
import android.widget.Switch
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class PrivacysetActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_privacyset)

        // 🔙 Back button
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Close activity and go back
        }

        // ⚙️ Switches
        val switchMedicalData = findViewById<Switch>(R.id.switchMedicalData)
        val switchAnonymous = findViewById<Switch>(R.id.switchAnonymous)
        val switchCamera = findViewById<Switch>(R.id.switchCamera)
        val switchLocation = findViewById<Switch>(R.id.switchLocation)
        val switchTwoFactor = findViewById<Switch>(R.id.switchTwoFactor)

        // ✅ Add listeners for changes
        switchMedicalData.setOnCheckedChangeListener { _, isChecked ->
            showToast("Medical Data Sharing: $isChecked")
        }

        switchAnonymous.setOnCheckedChangeListener { _, isChecked ->
            showToast("Anonymous Data: $isChecked")
        }

        switchCamera.setOnCheckedChangeListener { _, isChecked ->
            showToast("Camera Access: $isChecked")
        }

        switchLocation.setOnCheckedChangeListener { _, isChecked ->
            showToast("Location Services: $isChecked")
        }

        switchTwoFactor.setOnCheckedChangeListener { _, isChecked ->
            showToast("Two-Factor Authentication: $isChecked")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
