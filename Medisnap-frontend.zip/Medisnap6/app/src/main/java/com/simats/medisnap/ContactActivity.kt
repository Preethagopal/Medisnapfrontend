package com.simats.medisnap

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ContactActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_contact)

        // Chat with us -> Navigate to AiActivity
        findViewById<LinearLayout>(R.id.layoutChat).setOnClickListener {
            val intent = Intent(this, AiActivity::class.java)
            startActivity(intent)
        }

        // Call Support
        findViewById<LinearLayout>(R.id.layoutCall).setOnClickListener {
            val phone = "+919876543210"
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            startActivity(intent)
        }

        // Working Hours info
        findViewById<LinearLayout>(R.id.layoutHours).setOnClickListener {
            Toast.makeText(this, "Support available Mon-Sat, 9AM - 6PM", Toast.LENGTH_LONG).show()
        }
    }
}
