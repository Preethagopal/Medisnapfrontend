package com.simats.medisnap

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FaqActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_faq)

        // ✅ Handle insets (status bar, nav bar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 🔍 Search box
        val etSearchFaq: EditText = findViewById(R.id.etSearchFaq)

        etSearchFaq.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                // TODO: Filter FAQ list dynamically
                Toast.makeText(this@FaqActivity, "Searching: ${s.toString()}", Toast.LENGTH_SHORT).show()
            }
        })

        // 📂 Category buttons
        val btnAll: Button = findViewById(R.id.btnAll)
        val btnAccount: Button = findViewById(R.id.btnAccount)
        val btnMedical: Button = findViewById(R.id.btnMedical)
        val btnPrivacy: Button = findViewById(R.id.btnPrivacy)

        btnAll.setOnClickListener {
            Toast.makeText(this, "Showing All FAQs", Toast.LENGTH_SHORT).show()
        }

        btnAccount.setOnClickListener {
            Toast.makeText(this, "Showing Account FAQs", Toast.LENGTH_SHORT).show()
        }

        btnMedical.setOnClickListener {
            Toast.makeText(this, "Showing Medical FAQs", Toast.LENGTH_SHORT).show()
        }

        btnPrivacy.setOnClickListener {
            Toast.makeText(this, "Showing Privacy FAQs", Toast.LENGTH_SHORT).show()
        }
    }
}
