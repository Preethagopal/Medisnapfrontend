package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SavedreportsActivity : AppCompatActivity() {

    companion object {
        private const val MENU_EDIT = 1
        private const val MENU_DELETE = 2
    }

    private lateinit var backBtn: ImageView
    private lateinit var menuBtn: ImageView
    private lateinit var searchInput: EditText

    private lateinit var navHome: ImageView
    private lateinit var navSettings: ImageView
    private lateinit var navProfile: ImageView
    private lateinit var navReports: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_savedreports)

        // Apply system bar insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views with explicit types
        backBtn = findViewById<ImageView>(R.id.backBtn)
        menuBtn = findViewById<ImageView>(R.id.menuBtn)
        searchInput = findViewById<EditText>(R.id.searchInput)

        // Get bottom nav children (cast explicitly because the child views have no IDs)
        val bottomNav = findViewById<LinearLayout>(R.id.bottomNav)
        navHome = bottomNav.getChildAt(0) as ImageView
        navSettings = bottomNav.getChildAt(1) as ImageView
        navProfile = bottomNav.getChildAt(2) as ImageView
        navReports = bottomNav.getChildAt(3) as ImageView

        // Back button -> finish
        backBtn.setOnClickListener {
            finish()
        }

        // Menu button -> programmatic popup menu (no R.menu dependency)
        menuBtn.setOnClickListener {
            val popup = PopupMenu(this, menuBtn)
            popup.menu.add(Menu.NONE, MENU_EDIT, Menu.NONE, "Edit")
            popup.menu.add(Menu.NONE, MENU_DELETE, Menu.NONE, "Delete")

            popup.setOnMenuItemClickListener { item: MenuItem ->
                when (item.itemId) {
                    MENU_EDIT -> {
                        Toast.makeText(this, "Edit clicked", Toast.LENGTH_SHORT).show()
                        true
                    }
                    MENU_DELETE -> {
                        Toast.makeText(this, "Delete clicked", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }

        // Search input -> simple text watcher (replace with real filter as needed)
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // avoid spamming toasts on empty text
                if (!s.isNullOrEmpty()) {
                    Toast.makeText(this@SavedreportsActivity, "Searching: $s", Toast.LENGTH_SHORT).show()
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Bottom nav navigation
        navHome.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
            finish()
        }

        navSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        navReports.setOnClickListener {
            Toast.makeText(this, "Already on Reports page", Toast.LENGTH_SHORT).show()
        }
    }
}
