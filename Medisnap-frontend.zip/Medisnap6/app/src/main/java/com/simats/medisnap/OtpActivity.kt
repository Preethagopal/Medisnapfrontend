package com.simats.medisnap

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class OtpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_otp)

        // Handle edge-to-edge insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Find views
        val etOtp = findViewById<EditText>(R.id.etOtp)
        val btnVerifyOtp = findViewById<Button>(R.id.btnVerifyOtp)
        val tvResendOtp = findViewById<TextView>(R.id.tvResendOtp)

        // Verify OTP button click
        btnVerifyOtp.setOnClickListener {
            val otp = etOtp.text.toString().trim()

            if (otp.length == 4) {
                Toast.makeText(this, "OTP Verified: $otp", Toast.LENGTH_SHORT).show()
                // TODO: Add your OTP verification logic here
            } else {
                Toast.makeText(this, "Please enter a valid 4-digit OTP", Toast.LENGTH_SHORT).show()
            }
        }

        // Resend OTP click
        tvResendOtp.setOnClickListener {
            Toast.makeText(this, "Resending OTP...", Toast.LENGTH_SHORT).show()
            // TODO: Add resend OTP API logic here
        }
    }
}
