package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var btnSignOut: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_settings)

        // Handle system bars insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize Sign Out button
        btnSignOut = findViewById(R.id.btnSignOut)
        btnSignOut.setOnClickListener {
            Toast.makeText(this, "Signing Out...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Navigation for Section 1
        findViewById<TextView>(R.id.tvPrivacySecurity)?.setOnClickListener {
            startActivity(Intent(this, PrivacysetActivity::class.java))
        }

        findViewById<TextView>(R.id.tvExports)?.setOnClickListener {
            startActivity(Intent(this, ExportsActivity::class.java))
        }

        findViewById<TextView>(R.id.tvLanguage)?.setOnClickListener {
            startActivity(Intent(this, LanguageActivity::class.java))
        }

        // Navigation for Section 2
        findViewById<TextView>(R.id.tvPersonalInfo)?.setOnClickListener {
            startActivity(Intent(this, PersonalinfoActivity::class.java))
        }

        findViewById<TextView>(R.id.tvContact)?.setOnClickListener {
            startActivity(Intent(this, ContactActivity::class.java))
        }

        findViewById<TextView>(R.id.tvFAQ)?.setOnClickListener {
            startActivity(Intent(this, FaqActivity::class.java))
        }


    }
}
