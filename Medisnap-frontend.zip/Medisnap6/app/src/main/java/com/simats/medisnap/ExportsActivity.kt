package com.simats.medisnap

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ExportsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_exports)

        // Find all buttons by their visible text (since the XML has no IDs)
        val pdfButtons = findButtonsByText("PDF")
        val csvButtons = findButtonsByText("CSV")
        val printButtons = findButtonsByText("Print")

        // Expecting 3 sets (Medical Summary, Lab Results, Prescription History)
        if (pdfButtons.size >= 3 && csvButtons.size >= 3 && printButtons.size >= 3) {
            // --- Medical Summary (first card) ---
            pdfButtons[0].setOnClickListener { showToast("Exporting Medical Summary as PDF") }
            csvButtons[0].setOnClickListener { showToast("Exporting Medical Summary as CSV") }
            printButtons[0].setOnClickListener { showToast("Printing Medical Summary") }

            // --- Lab Results (second card) ---
            pdfButtons[1].setOnClickListener { showToast("Exporting Lab Results as PDF") }
            csvButtons[1].setOnClickListener { showToast("Exporting Lab Results as CSV") }
            printButtons[1].setOnClickListener { showToast("Printing Lab Results") }

            // --- Prescription History (third card) ---
            pdfButtons[2].setOnClickListener { showToast("Exporting Prescription History as PDF") }
            csvButtons[2].setOnClickListener { showToast("Exporting Prescription History as CSV") }
            printButtons[2].setOnClickListener { showToast("Printing Prescription History") }
        } else {
            showToast("Some export buttons are missing. Consider adding IDs for reliability.")
        }
    }

    private fun findButtonsByText(text: String): List<Button> {
        val matches = mutableListOf<Button>()
        val root = window.decorView.findViewById<View>(android.R.id.content)
        fun dfs(v: View) {
            if (v is Button && v.text.toString().equals(text, ignoreCase = true)) {
                matches.add(v)
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) dfs(v.getChildAt(i))
            }
        }
        dfs(root)
        return matches
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
