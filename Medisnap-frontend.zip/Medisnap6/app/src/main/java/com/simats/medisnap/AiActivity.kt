package com.simats.medisnap

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AiActivity : AppCompatActivity() {

    private lateinit var chatLayout: LinearLayout
    private lateinit var inputMessage: EditText
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai)

        chatLayout = findViewById(R.id.chatLayout)
        inputMessage = findViewById(R.id.inputMessage)
        sendButton = findViewById(R.id.sendButton)

        sendButton.setOnClickListener {
            val userMessage = inputMessage.text.toString().trim()
            if (userMessage.isNotEmpty()) {
                // Show user message (right side)
                addMessage("You: $userMessage", true)

                // Get bot response
                val reply = getBotResponse(userMessage)

                // Show bot message (left side)
                addMessage("Bot: $reply", false)

                inputMessage.text.clear()
            }
        }
    }

    // Function to display messages in chat area
    private fun addMessage(message: String, isUser: Boolean) {
        val textView = TextView(this)
        textView.text = message
        textView.textSize = 16f
        textView.setPadding(24, 16, 24, 16)

        // Background bubble color
        if (isUser) {
            textView.setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            textView.setBackgroundColor(0xFFD1F7C4.toInt()) // light green for user
        } else {
            textView.setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            textView.setBackgroundColor(0xFFE3E3E3.toInt()) // light gray for bot
        }

        // Align left/right
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(12, 8, 12, 8)

        params.gravity = if (isUser) Gravity.END else Gravity.START
        textView.layoutParams = params

        // Rounded corners (optional)
        textView.background = resources.getDrawable(android.R.drawable.toast_frame, theme)

        chatLayout.addView(textView)

        // Auto scroll to bottom
        val scrollView = findViewById<ScrollView>(R.id.scrollView)
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // Smarter Chatbot responses
    private fun getBotResponse(message: String): String {
        val msg = message.lowercase().replace("?", "").replace("!", "")
        return when {
            msg.contains("hi") || msg.contains("hey") -> "Hi there! 👋"
            msg.contains("hello") -> "Hello! How can I help you with your medical report today?"
            msg.contains("how are you") -> "I'm fine, thank you! How are you feeling today?"
            msg.contains("medisnap") -> "MediSnap helps you simplify and understand your medical reports."
            msg.contains("hemoglobin") -> "Hemoglobin is the protein in your blood that carries oxygen."
            msg.contains("rbc") -> "RBC means Red Blood Cells. They carry oxygen throughout your body."
            msg.contains("wbc") -> "WBC means White Blood Cells. They help fight infections."
            msg.contains("platelet") -> "Platelets help your blood clot and stop bleeding."
            msg.contains("cholesterol") -> "Cholesterol is a type of fat in your blood. High levels can increase heart risk."
            msg.contains("diabetes") -> "Diabetes is a condition where your blood sugar is too high."
            msg.contains("bp") || msg.contains("blood pressure") -> "Normal BP is usually around 120/80 mmHg."
            msg.contains("bmi") -> "BMI shows if your weight is healthy for your height."
            msg.contains("fever") -> "Fever is when your body temperature is above 100.4°F (38°C)."
            msg.contains("vitamin d") -> "Vitamin D helps your body absorb calcium and keeps bones strong."
            msg.contains("anemia") -> "Anemia happens when you don’t have enough red blood cells."
            msg.contains("thyroid") -> "The thyroid controls metabolism. Problems cause weight/tiredness issues."
            msg.contains("covid") -> "COVID-19 is a viral infection. Symptoms: fever, cough, breathing issues."
            msg.contains("asthma") -> "Asthma makes airways narrow, causing breathing difficulty."
            msg.contains("heart attack") -> "A heart attack is when blood flow to the heart is blocked."
            msg.contains("stroke") -> "Stroke occurs when blood supply to the brain is interrupted."
            msg.contains("kidney") -> "Kidneys filter waste. Problems can cause swelling, fatigue, abnormal tests."
            msg.contains("liver") -> "The liver detoxifies blood, produces bile, stores energy."
            msg.contains("cancer") -> "Cancer is uncontrolled cell growth. Early detection helps."
            msg.contains("allergy") -> "Allergy is when your body reacts to dust, pollen, food, etc."
            msg.contains("migraine") -> "Migraine is a strong headache often with nausea/light sensitivity."
            msg.contains("hypertension") -> "Hypertension means high blood pressure (above 140/90 mmHg)."
            msg.contains("hypotension") -> "Hypotension means low blood pressure, causing dizziness."
            msg.contains("arthritis") -> "Arthritis is joint inflammation, causing pain and stiffness."
            msg.contains("depression") -> "Depression is sadness/low energy for long periods."
            msg.contains("anxiety") -> "Anxiety is when you feel nervous or worried excessively."
            msg.contains("sleep") || msg.contains("insomnia") -> "Insomnia means difficulty sleeping."
            msg.contains("hydration") -> "Drinking enough water supports all organs."
            msg.contains("diet") -> "A healthy diet has fruits, veggies, grains, protein, low sugar/fat."
            msg.contains("thank") -> "You're welcome! 😊"
            msg.contains("bye") -> "Goodbye! Stay healthy and take care."
            else -> "Sorry, I don’t understand that yet. Please try another medical query."
        }
    }
}
