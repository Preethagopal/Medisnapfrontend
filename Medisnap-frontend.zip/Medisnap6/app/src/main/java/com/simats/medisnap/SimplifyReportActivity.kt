package com.simats.medisnap

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class SimplifyReportActivity : AppCompatActivity() {

    private lateinit var btnUpload: Button
    private lateinit var btnSimplify: Button
    private lateinit var tvResult: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var pickFileLauncher: ActivityResultLauncher<Intent>

    private var selectedFile: Uri? = null
    private var selectedReport: String = ""

    // Emily Johnson report
    private val emilyReport = """
        ★ Patient Information
          • Name: Emily Johnson
          • Date of Birth: 01/15/1989
          • Patient ID: 987654321
          • Date of Report: 03/10/2024
          • Referring Physician: Dr. Alan Green, MD
          • Specialty: Cardiology
          • Contact Information: [Physician's Contact Information]

        ★ Introduction
          This medical report is prepared for Emily Johnson following her consultation and evaluation 
          in the cardiology department on 03/08/2024. The purpose is to document her cardiac health 
          status and outline the management plan recommended.

        ★ Medical History
          Ms. Johnson has a history of hypertension, diagnosed three years ago, managed with medication. 
          No known drug allergies. Family history of coronary artery disease (father). She is a non-smoker 
          and maintains an active lifestyle.

        ★ Presenting Complaints
          • Intermittent chest pain (on exertion)
          • Occasional palpitations over the last two months
          • Shortness of breath during jogging sessions (previously well-tolerated)

        ★ Diagnostic Tests Conducted
          (Section header present, but details are not included in the image.)
    """.trimIndent()

    // Aimee Little report
    private val aimeeReport = """
        ★ Patient Information
          • Name: Aimee Little
          • Patient Number: 1000010659748
          • Exam Date: 6/8/2016, 5:22:37 PM

        ★ History
          • 38-year-old widowed Canadian woman
          • Chief complaint: “I am completely miserable since my dear husband died.”
          • Husband died of cancer three months ago
          • Current depressive symptoms attributed to bereavement

        ★ Current Symptoms
          • Decreased appetite and weight loss (~5 pounds in one month)
          • Concentration difficulties; mind often wanders
          • Crying spells, sadness, insomnia
          • Denies suicidal ideas or intentions
          • No history of manic/hypomanic episodes
          • Depression severity: moderate

        ★ Anxiety Symptoms
          • Present for months, occurring daily
          • Difficulty concentrating, restlessness
          • Trouble sleeping, exaggerated startle response

        ★ Problem Pertinent Review of Symptoms
          • No obsessive or compulsive behaviors
          • No hallucinations, delusions, or psychotic symptoms

        ★ Past Psychiatric History
          • No history of substance withdrawal
          • Never psychiatrically hospitalized
          • Outpatient mental health treatment in her 20s for anxiety (lasted months, no medication prescribed)
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simplify_report)

        // view bindings
        btnUpload = findViewById(R.id.btnUpload)
        btnSimplify = findViewById(R.id.btnSimplify)
        tvResult = findViewById(R.id.tvResult)
        scrollView = findViewById(R.id.scrollView)

        // style
        tvResult.setTextColor(Color.parseColor("#1E88E5"))
        tvResult.isFocusable = true
        tvResult.isClickable = true

        // initial visibility
        btnSimplify.visibility = View.GONE
        scrollView.visibility = View.GONE

        // register result launcher
        pickFileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val uri = data?.data
                if (uri != null) {
                    selectedFile = uri
                    processFile(uri)
                } else {
                    Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // open file chooser
        btnUpload.setOnClickListener {
            val picker = Intent(Intent.ACTION_GET_CONTENT)
            picker.type = "*/*"
            val mimeTypes = arrayOf("application/pdf", "image/*", "text/plain")
            picker.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            pickFileLauncher.launch(Intent.createChooser(picker, "Select Report"))
        }

        // show full report when simplify is clicked
        btnSimplify.setOnClickListener {
            scrollView.visibility = View.VISIBLE
            tvResult.text = selectedReport
            scrollView.post { scrollView.fullScroll(View.FOCUS_UP) }
        }
    }

    // process uploaded file (simulation based on filename)
    private fun processFile(uri: Uri) {
        try {
            val fileName = getFileName(uri).lowercase()

            selectedReport = when {
                fileName.contains("emily") -> {
                    Toast.makeText(this, "Emily Johnson report loaded", Toast.LENGTH_SHORT).show()
                    emilyReport
                }
                fileName.contains("aimee") -> {
                    Toast.makeText(this, "Aimee Little report loaded", Toast.LENGTH_SHORT).show()
                    aimeeReport
                }
                else -> {
                    Toast.makeText(this, "Unknown file, defaulting to Emily Johnson report", Toast.LENGTH_SHORT).show()
                    emilyReport
                }
            }

            btnSimplify.visibility = View.VISIBLE

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error reading file", Toast.LENGTH_SHORT).show()
        }
    }

    // helper to get file name from uri
    private fun getFileName(uri: Uri): String {
        var name = "unknown"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    name = it.getString(index)
                }
            }
        }
        return name
    }
}
