package com.simats.medisnap

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PersonalinfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_personalinfo)

        // Handle system bars insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 🔙 Back Button
        val backBtn: ImageView = findViewById(R.id.backBtn)
        backBtn.setOnClickListener {
            finish() // Go back to previous screen
        }

        // 📸 Change Photo Button
        val changePhoto: ImageButton = findViewById(R.id.changePhoto)
        changePhoto.setOnClickListener {
            Toast.makeText(this, "Change photo clicked", Toast.LENGTH_SHORT).show()
            // Later: open gallery/camera picker here
        }

        // 💾 Save Button
        val saveButton: Button = findViewById(R.id.saveButton)
        saveButton.setOnClickListener {
            Toast.makeText(this, "Changes saved successfully!", Toast.LENGTH_SHORT).show()
            // Later: Save updated info to database / API
        }
    }
}
