package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ReportActivity : AppCompatActivity() {

    private lateinit var backButton: ImageView
    private lateinit var downloadBtn: LinearLayout
    private lateinit var printBtn: LinearLayout
    private lateinit var shareBtn: LinearLayout
    private lateinit var moreBtn: LinearLayout

    private lateinit var settingsBtn: ImageView
    private lateinit var homeBtn: ImageView
    private lateinit var profileBtn: ImageView
    private lateinit var reportBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_report)

        // Handle edge-to-edge insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Top bar back button
        backButton = findViewById(R.id.backButton)
        backButton.setOnClickListener { finish() }

        // Action buttons
        downloadBtn = findViewById(R.id.downloadBtn)
        printBtn = findViewById(R.id.printBtn)
        shareBtn = findViewById(R.id.shareBtn)
        moreBtn = findViewById(R.id.moreBtn)

        downloadBtn.setOnClickListener {
            Toast.makeText(this, "Downloading report...", Toast.LENGTH_SHORT).show()
        }
        printBtn.setOnClickListener {
            Toast.makeText(this, "Sending to printer...", Toast.LENGTH_SHORT).show()
        }
        shareBtn.setOnClickListener {
            Toast.makeText(this, "Sharing report...", Toast.LENGTH_SHORT).show()
        }
        moreBtn.setOnClickListener {
            Toast.makeText(this, "More options...", Toast.LENGTH_SHORT).show()
        }

        // Bottom navigation
        val bottomNav = findViewById<LinearLayout>(R.id.bottomNav)
        settingsBtn = bottomNav.findViewById(R.id.settingsIcon)
        homeBtn = bottomNav.findViewById(R.id.homeIcon)
        profileBtn = bottomNav.findViewById(R.id.profileIcon)
        reportBtn = bottomNav.findViewById(R.id.reportIcon)

        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        homeBtn.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }
        profileBtn.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        reportBtn.setOnClickListener {
            Toast.makeText(this, "Already in Reports", Toast.LENGTH_SHORT).show()
        }
    }
}
