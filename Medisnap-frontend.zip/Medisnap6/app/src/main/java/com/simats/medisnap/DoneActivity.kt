package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DoneActivity : AppCompatActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var btnContinue: Button
    private lateinit var navHome: ImageButton
    private lateinit var navSettings: ImageButton
    private lateinit var navReports: ImageButton
    private lateinit var navProfile: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_done) // make sure this XML exists

        // Handle system bars padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize buttons – make sure IDs match your XML
        btnBack = findViewById(R.id.btnBack)
        btnContinue = findViewById(R.id.btnContinue)

        navHome = findViewById(R.id.navHome)
        navSettings = findViewById(R.id.navSettings)
        navReports = findViewById(R.id.navReports)
        navProfile = findViewById(R.id.navProfile)

        // Back button closes DoneActivity
        btnBack.setOnClickListener { finish() }

        // Continue button → example: go back to Gallery
        btnContinue.setOnClickListener {
            val intent = Intent(this, GalleryActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Bottom navigation
        navHome.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
            finish()
        }

        navSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        navReports.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}
