package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class GalleryActivity : AppCompatActivity() {

    private lateinit var settingsBtn: ImageView
    private lateinit var profileBtn: ImageView
    private lateinit var reportBtn: ImageView
    private lateinit var tvSelect: TextView
    private lateinit var btnBack: ImageButton
    private lateinit var btnUpload: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_gallery)

        // Handle system bars insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        settingsBtn = findViewById(R.id.navSettings1)
        profileBtn = findViewById(R.id.navProfile1)
        reportBtn = findViewById(R.id.navReports1)
        tvSelect = findViewById(R.id.tvSelect)
        btnBack = findViewById(R.id.btnBack)
        btnUpload = findViewById(R.id.btnUpload)

        // Bottom Navigation
        settingsBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        profileBtn.setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        reportBtn.setOnClickListener { startActivity(Intent(this, ReportActivity::class.java)) }

        // Back Button
        btnBack.setOnClickListener { finish() }

        // ✅ Upload Button → Navigate to DoneActivity
        btnUpload.setOnClickListener {
            Log.d("GalleryActivity", "Upload button clicked")
            val intent = Intent(this@GalleryActivity, DoneActivity::class.java)
            startActivity(intent)
        }

        // Select Text → Navigate to SelectionsActivity
        tvSelect.setOnClickListener {
            startActivity(Intent(this@GalleryActivity, SelectionsActivity::class.java))
        }
    }
}
