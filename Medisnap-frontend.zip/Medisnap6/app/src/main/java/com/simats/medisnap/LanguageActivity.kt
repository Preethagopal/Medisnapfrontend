package com.simats.medisnap

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LanguageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_language)

        // Handle system bar insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Back button
        findViewById<ImageView>(R.id.backButton).setOnClickListener {
            finish()
        }

        // Current language
        val currentLanguage = findViewById<TextView>(R.id.currentLanguage)

        // Popular language options
        findViewById<TextView>(R.id.langSpanish).setOnClickListener {
            updateLanguage("Spanish", currentLanguage)
        }
        findViewById<TextView>(R.id.langFrench).setOnClickListener {
            updateLanguage("French", currentLanguage)
        }
        findViewById<TextView>(R.id.langGerman).setOnClickListener {
            updateLanguage("German", currentLanguage)
        }
        findViewById<TextView>(R.id.langItalian).setOnClickListener {
            updateLanguage("Italian", currentLanguage)
        }
        findViewById<TextView>(R.id.langPortuguese).setOnClickListener {
            updateLanguage("Portuguese", currentLanguage)
        }

        // Search box (for now just a toast on text input)
        val searchLanguage = findViewById<EditText>(R.id.searchLanguage)
        searchLanguage.setOnEditorActionListener { textView, _, _ ->
            val query = textView.text.toString().trim()
            if (query.isNotEmpty()) {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
            true
        }
    }

    private fun updateLanguage(language: String, currentLanguage: TextView) {
        currentLanguage.text = language
        Toast.makeText(this, "Language changed to $language", Toast.LENGTH_SHORT).show()
    }
}
