package com.simats.medisnap

import android.app.Activity
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class UploadActivity : AppCompatActivity() {

    private lateinit var btnUploadCenter: ImageButton
    private lateinit var imgPreview: ImageView
    private lateinit var tvSelectedFile: TextView
    private lateinit var navReports: ImageButton
    private lateinit var navProfile: ImageButton
    private lateinit var navSettings: ImageButton
    private lateinit var btnSimplify: Button

    private val PICK_FILE = 101
    private var selectedFile: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        // UI elements
        btnUploadCenter = findViewById(R.id.btnUploadCenter)
        imgPreview = findViewById(R.id.imgPreview)
        tvSelectedFile = findViewById(R.id.tvSelectedFile)
        navReports = findViewById(R.id.navReports)
        navProfile = findViewById(R.id.navProfile)
        navSettings = findViewById(R.id.navSettings)
        btnSimplify = findViewById(R.id.btnSimplify)

        // Upload button click
        btnUploadCenter.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "*/*"
            val mimeTypes = arrayOf("image/*", "application/pdf")
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            startActivityForResult(Intent.createChooser(intent, "Select Report"), PICK_FILE)
        }

        // Simplify button click
        btnSimplify.setOnClickListener {
            if (selectedFile != null) {
                val intent = Intent(this, SimplifyReportActivity::class.java)
                intent.putExtra("fileUri", selectedFile.toString()) // pass file to next screen
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please upload a file first", Toast.LENGTH_SHORT).show()
            }
        }

        // Bottom navigation clicks
        navReports.setOnClickListener {
            val intent = Intent(this, ReportActivity::class.java)
            startActivity(intent)
        }
        navProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        navSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE && resultCode == Activity.RESULT_OK) {
            selectedFile = data?.data
            if (selectedFile != null) {
                val type = contentResolver.getType(selectedFile!!)
                when {
                    type?.startsWith("image/") == true -> {
                        imgPreview.setImageURI(selectedFile)
                        imgPreview.visibility = ImageView.VISIBLE
                        tvSelectedFile.text = ""
                        btnSimplify.visibility = Button.VISIBLE
                    }
                    type == "application/pdf" -> {
                        renderPdfPage(selectedFile!!)
                        tvSelectedFile.text = "PDF Loaded"
                        btnSimplify.visibility = Button.VISIBLE
                    }
                    else -> {
                        imgPreview.visibility = ImageView.GONE
                        tvSelectedFile.text = "Unsupported file type"
                        btnSimplify.visibility = Button.GONE
                    }
                }
                Toast.makeText(this, "File Selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderPdfPage(uri: Uri) {
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val file = File(cacheDir, "temp.pdf")
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()

            val fileDescriptor =
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fileDescriptor)
            if (renderer.pageCount > 0) {
                val page = renderer.openPage(0)
                val bitmap = android.graphics.Bitmap.createBitmap(
                    page.width,
                    page.height,
                    android.graphics.Bitmap.Config.ARGB_8888
                )
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                imgPreview.setImageBitmap(bitmap)
                imgPreview.visibility = ImageView.VISIBLE
                page.close()
            }
            renderer.close()
            fileDescriptor.close()
        } catch (e: Exception) {
            e.printStackTrace()
            tvSelectedFile.text = "Error showing PDF"
        }
    }
}
