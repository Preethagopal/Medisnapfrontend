package com.simats.medisnap

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SelectActivity : AppCompatActivity() {

    private lateinit var settingsbtn: ImageButton
    private lateinit var profilebtn: ImageButton
    private lateinit var reportbtn: ImageButton
    private lateinit var selectText: TextView   // Select TextView
    private lateinit var backBtn: ImageButton   // Back Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_select)   // ✅ Correct layout

        // Handle system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Bind views
        settingsbtn = findViewById(R.id.navSettings)
        profilebtn = findViewById(R.id.navProfile)
        reportbtn = findViewById(R.id.navReports)
        selectText = findViewById(R.id.tvSelect)   // ✅ important
        backBtn = findViewById(R.id.btnBack)

        // ✅ Navigate to GalleryActivity when "Select" is clicked
        selectText.setOnClickListener {
            val intent = Intent(this, GalleryActivity::class.java)
            startActivity(intent)
        }

        // ✅ Back button goes back to UploadActivity
        backBtn.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Bottom navigation
        settingsbtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        profilebtn.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        reportbtn.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
    }
}
